import pytesseract

def img_ocr(img_ori):
    text = pytesseract.image_to_string(img_ori, config='--psm 8').strip()  # Use PSM 8 for single word/line of text
    if text.isnumeric():
        return text
    else:
        return False

