import easyocr


def img_ocr(img_ori):
    reader = easyocr.Reader(['en'],gpu=True)
    text = reader.readtext(img_ori)  # Use PSM 8 for single word/line of text
    if text and text[0][1].isnumeric():
        return text[0][1]
    else:
        return False
