import torch
import cv2
from pathlib import Path
import yolov5
from util.imgocr import img_ocr
# 모델 로드
model = yolov5.load('./best.pt')

# 비디오 파일 경로
video_path = './440waiting.MOV'

# 비디오 캡처 객체 생성
cap = cv2.VideoCapture(video_path)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # 모델을 사용하여 프레임에서 객체 탐지
    results = model(frame)

    # 결과를 이미지에 그리기
    for _, row in results.pandas().xyxy[0].iterrows():
        # 바운딩 박스 좌표
        x1, y1, x2, y2 = int(row['xmin']), int(row['ymin']), int(row['xmax']), int(row['ymax'])
        # 클래스 이름과 신뢰도
        if row['name']=='busnum' and row['confidence']>=0.8:
            bus_roi = frame[int(y1):int(y2), int(x1):int(x2)]
            ocr_result = img_ocr(bus_roi)
            if ocr_result:
                label = f'{row['name']} {row['confidence']:.2f}: {ocr_result}' 
                print(label)
            else:
                label = ''
            # 바운딩 박스 그리기
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            # 클래스 이름과 신뢰도 그리기
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    # 프레임을 화면에 표시 (선택 사항)
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 리소스 해제
cap.release()
cv2.destroyAllWindows()
