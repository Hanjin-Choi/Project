from gtts import gTTS
from pydub import AudioSegment
from pydub.playback import play
from io import BytesIO
import os

from playsound import playsound


def play_audio(filename, content ='', lang ='en'):
    filename = './sound_source/'+filename+'.mp3'
    if os.path.exists(filename):
        playsound(filename)
    else:
        tts = gTTS(text = content, lang=lang)
        playsound(filename)
