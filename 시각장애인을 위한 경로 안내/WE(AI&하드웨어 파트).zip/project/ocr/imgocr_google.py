import os
import io
import numpy as np
from PIL import Image
from google.cloud import vision

# Google Cloud Vision API Ű ��� ����
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/orin/key/busocr-3092ada759de.json"

def img_ocr(img_ori):
    try:
        extracted_text =''
        client = vision.ImageAnnotatorClient()
        img_pil = Image.fromarray(img_ori)
        buffered = io.BytesIO()
        img_pil.save(buffered, format="JPEG")
        content = buffered.getvalue()
        image = vision.Image(content=content)
        response = client.text_detection(image=image)
        texts = response.text_annotations
        # Extract text descriptions from the OCR response
        if texts :
            extracted_text = [text.description for text in texts if text.description.isdigit()][0]
        # Combine all extracted texts into a single string
        print(f"Extracted text: {extracted_text}")  # Print for debugging
        return extracted_text
    except Exception as e:
        print(f"Error during OCR: {e}")
        return ""
