import paho.mqtt.client as mqtt
import ssl
import os
import json
import time

# AWS IoT Core 엔드포인트
AWS_IOT_ENDPOINT = 'a3j29icjdebdp7-ats.iot.ap-northeast-2.amazonaws.com'

# 인증서 및 키 파일 경로 (절대 경로로 수정)
CA_CERT_PATH = '/home/orin/certs/AmazonRootCA1.pem'
CERT_FILE_PATH = '/home/orin/certs/certificate.pem.crt'
KEY_FILE_PATH = '/home/orin/certs/private.pem.key'

# MQTT 주제와 메시지
SEND_TOPIC = 'topic_2'
MESSAGE = 'p3767-0005'

# MQTT 클라이언트 콜백 함수
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    

def on_message(client, userdata, msg):
    pass


# 메시지 수신 대기
def main():
    # MQTT 클라이언트 생성
    client = mqtt.Client()

    # 클라이언트 인증 설정
    client.tls_set(ca_certs=CA_CERT_PATH,
                certfile=CERT_FILE_PATH,
                keyfile=KEY_FILE_PATH,
                tls_version=ssl.PROTOCOL_TLSv1_2)

    client.on_connect = on_connect
    client.on_message = on_message

    # 서버에 연결
    client.connect(AWS_IOT_ENDPOINT, port=8883, keepalive=60)

    client.publish(SEND_TOPIC, MESSAGE)
    
    client.loop_start()
    time.sleep(0.5)
    client.loop_stop()

    client.disconnect()


