import threading                        #멀티스레딩
from bus import main as busnumber       #버스번호 인식 모듈
from traffic import main as traffic     #신호등 인식 모듈
from kickboard import main as kickboard #킥보드 인식 모듈
from board import SDA, SCL              #젯슨 통신
from imu_mpu6050 import MPU6050         #자이로센서
import busio
import time
import math
import cv2
import json
from constant import emergency
from connect import main as connect
from data_receive import main as receive
from data_send import main as send
from lock import file_lock
from sound import play_audio

class MyThread(threading.Thread):
    def __init__(self, target=None, args=()):
        super().__init__(target=target, args=args)
        self.result = None

    def run(self):
        try:
            if self._target is not None:
                self.result = self._target(*self._args)
        finally:
            del self._target, self._args, self._kwargs

    def get_result(self):
        return self.result

def init():
    with open("data_receive.json",'w') as f:
        data= {
            "flag" : 0,
            "bus_num" : None,
        }
        json.dump(data,f)

# 자이로 함수
def gyro():
    global emergency
    i2c = busio.I2C(SCL, SDA)
    IMU = MPU6050(i2c)

    tLoop = 0
    rollG = 0
    pitchG = 0
    rollComp = 0
    pitchComp = 0

    # 각 방향 회전 각도 제한
    rollLimit = 60
    pitchLimit = 60

    warning_cnt = 0

    cnt = 0
    flag = 0

    while True:
        # 대충 한 사이클에 13ms (delay 없을 때)
        # IMU 센서 측정 시간 저장
        tStart = time.time() * 1000  # Convert to millisecond
        
        # 가속도 센서 데이터 저장
        accel_data = IMU.get_accel_data(g=True)
        xAccel = accel_data['x']
        yAccel = accel_data['y']
        zAccel = accel_data['z']

        # 자이로 센서 데이터 저장
        gyro_data = IMU.get_gyro_data()
        xGyro = gyro_data['x']
        yGyro = gyro_data['y']
        zGyro = gyro_data['z']

        # 상보 필터
        rollG = rollG + yGyro * tLoop
        pitchG = pitchG + xGyro * tLoop

        # 각도 단위 변환
        rollA = math.atan2(xAccel, zAccel) / (2 * math.pi) * 360
        pitchA = math.atan2(yAccel, zAccel) / (2 * math.pi) * 360
    
        rollComp = rollA * 0.005 + 0.995 * (rollComp + yGyro * tLoop)
        pitchComp = pitchA * 0.005 + 0.995 * (pitchComp + xGyro * tLoop)

        # 대충 250ms에 한번씩 잼
        cnt = cnt + 1
        if cnt == 60:
            cnt = 0
            #print(f'Pitch: {pitchComp:.2f}, Roll:  {rollComp:.2f}')
            
            # abs로 앞뒤 방향 고려
            if pitchLimit <= abs(pitchComp) and rollLimit <= abs(rollLimit):
                warning_cnt += 1
                if 10 < warning_cnt and not emergency:  # 위험 한 상황 10번 초과 -> 250ms * 10, 약 3초 이상 위험 상황 지속시
                    emergency = 1
                    send()
                    with open('constant.py', 'w') as f:
                        f.write('emergency=1')
 
                    play_audio('warning')
            elif emergency:  # emergency 상황에서 normal로 돌아올 때
                warning_cnt = 0
                emergency = 0
                with open('constant.py', 'w') as f:
                    f.write('emergency=0')
            else:
                warning_cnt = 0

        tStop = time.time() * 1000  # Convert to milliseconds
        tLoop = (tStop - tStart) * 0.001  # Convert to seconds

def main():
    while True:
        results = flag = bus_num = None
        with file_lock:
            with open('data_receive.json','r', encoding='utf-8') as f:
                tmp = f.read()
            #print(tmp)
            data = json.loads(tmp)

        if data.get("flag"):
            flag = data.get("flag")
            bus_num = data.get("bus_num")
            if emergency:
                flag = 0

        # 버스 번호판 인식
        if flag == 1:
            play_audio('bus')
            thread_2 = MyThread(target=busnumber, args=(bus_num,))
            thread_2.start()
            thread_2.join()
            results = thread_2.get_result()
            cap = cv2.VideoCapture(0)
            cap.release()
            cv2.destroyAllWindows()
        # 신호등 인식
        elif flag == 2:
            play_audio('traffic')
            thread_2 = MyThread(target=traffic)
            thread_2.start()
            thread_2.join()
            results = thread_2.get_result()
            cap = cv2.VideoCapture(0)
            cap.release()
            cv2.destroyAllWindows()
        # 길거리 킥보드 인식
        elif flag == 3:
            play_audio('obstacle')
            thread_2 = MyThread(target=kickboard)
            thread_2.start()
            thread_2.join()
            results = thread_2.get_result()
            cap = cv2.VideoCapture(0)
            cap.release()
            cv2.destroyAllWindows()

        # 결과값 DB 테이블에 result column에 저장
        if flag and results != 'emergency' and results != None and results != 'Done':
            init()
        elif results == 'emergency':
            print("gohome")

# 멀티 스레드로 IMU 센서 데이터 값 gyro()로 실행
thread_1 = threading.Thread(target=gyro)
thread_1.start()

init()
connect()
play_audio('connect')
thread_3 = threading.Thread(target=receive)
thread_3.start()
play_audio('operation')
main()
